# JSR Fitness Premium — Assets v0.2.0

Biblioteca organizada por categoria e IDs oficiais.

- `catalogo.json`: fonte de dados para o app; caminhos nulos significam imagem pendente.
- `catalogo.csv`: controle editorial.
- `imagens/`: WebP individuais existentes, sem validação anatômica.
- `referencias_visuais_nao_integrar/`: painéis compostos; alguns contêm IDs e nomes incorretos e **não** devem ser publicados como exercícios.

## Regras de integração
Use apenas os caminhos não nulos no JSON e implemente placeholder para ausentes. Não inferir 116 imagens a partir dos painéis. Conferir qualidade dos recortes e coerência entre execução e anatomia antes da publicação educativa.

## GitHub
Criar repositório privado `jsr-fitness-premium-assets` e enviar a estrutura descompactada. Não há upload GitHub confirmado neste pacote.
